<div style="margin:0;background:rgb(229,229,229);min-height:400px;padding-top:40px">
  <div class="adM">
  </div>
  <div style="width:590px;background:rgb(255,255,255);margin:0 auto 0">
    <div class="adM">
    </div>
    <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tbody>
        <tr>
          <td valign="middle" style="margin:5px 0 0;text-align:left;color:rgb(0,0,0);font:14px arial,helvetica,sans-serif;font-weight:bold;padding:17px 35px;background:rgb(249,249,249)">Pestcity USA<br></td>
          <td align="right" style="padding:10px 30px;background:rgb(249,249,249)"><br></td>
        </tr>
      </tbody>
    </table>
    <div style="color:rgb(0,0,0);font:14px arial,helvetica,sans-serif;line-height:18px;padding:20px 35px">
      <div style="margin-bottom:15px;margin-top:10px">Hi {!! $data->full_name !!},<br></div>
      <div style="">
        <div style="font-size:14px;margin-bottom:18px">
          {!! $data->staffname !!} has been assigned to you for your {!! $data->sname !!}.<br>
          <br><br>
          <b>Your professional:</b><br><br>
          {!! $data->staffname !!}<br>
          Name: {!! $data->staffname !!}<br>
          Phone: {!! $data->staffname !!}<br>

          <b>Your service details:</b><br><br>
          Service name:{!! $data->sname !!}<br>
          Date:{!! $data->sstart_date !!}<br>
          Time:{!! $data->sstart_date !!}<br>
        </div>
        <div style="font-size:14px;margin-bottom:18px">
          <b>*Note:</b> this link,https://www.pestcityusa.com/make-payment/ to pay now or pay online once service is done.
        </div>
      </div>
      <div style="font-weight:bold">Thank You,<br></div>
      <div style="font-weight:bold">Pest City USA<br></div>

    </div>
  </div>
</div>